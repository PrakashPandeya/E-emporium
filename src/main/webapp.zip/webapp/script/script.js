// script.js
function ddc() {
	const dropdownContent = document.getElementById('myDropdown');
	dropdownContent.classList.toggle("ddc-shown");
}

